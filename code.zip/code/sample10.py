# Assignment on bitwise operators
"""Given two integers, write a Python program that:

Prints the result of a & b, a | b, and a ^ b.
Shifts the bits of two positions to the left (a << 2).
Shifts the bits of b one position to the right (b >> 1)."""

a = 1
b = 2

print(a&b)
print(a|b)
print(a<<2)
print(b>>1)

