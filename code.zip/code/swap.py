# swap 2 numbers without using 3rd variable
a = 10
b = 12

print("a & b before swapping ",a,b)
a , b = b, a

print("a & b after swapping ",a,b)
