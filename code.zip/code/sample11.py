#assigment 1

"""List Manipulation Exercise:

Create a list of 5 items (strings or numbers).
Add a new item to the end of the list and another at the second position.
Remove the third item from the list.
Print the list after each operation."""

item = [1,2,6,7,5,3,4]

print("initial list",item)

# Add a new item to the end of the list
item.append(10)

print(item)

# add item at the second position
item.insert(1,10)

print(item)

# Remove the third item from the list.

item.pop(2)

print(item)





