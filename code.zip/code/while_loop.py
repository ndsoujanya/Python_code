
# Write a program that counts from 1 to 10 using a while loop.

count = 0

while count <= 10:

    print(f"Current count is {count}")

    count += 1
