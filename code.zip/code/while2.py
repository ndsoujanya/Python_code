#Write a program that counts down from 10 to 1 using a while loop
# and prints "Happy New Year!" after the countdown is over.

count = 10

while count <= 10:

    print(count)

    if count == 0:

        print("Happy new year....")
        break

    count -= 1