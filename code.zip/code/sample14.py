"""
Create a list of numbers and:

Sort it in descending order.
Reverse the sorted list and print it.

"""

num_list = [1,2,45,6,78,0]
# prints list element in ascending order
num_list.sort()
print(num_list)

# as we are reversing the sorted list it prints list element in descending order
num_list.reverse()
print(num_list)