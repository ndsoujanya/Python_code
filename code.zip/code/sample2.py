a = 10
b = 12

# according to precedence a * b takes 1st precedence , then divide, addition and subtraction
print(a*b+a-b/a) # 120 + 10 - 1.2 = 128.8



